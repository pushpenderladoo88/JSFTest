package com.amazonaws.hackathon;

import java.util.ArrayList;
import java.util.List;

import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.services.s3.AmazonS3Client;
import com.amazonaws.services.s3.model.AccessControlList;
import com.amazonaws.services.s3.model.Bucket;
import com.amazonaws.services.s3.model.GetObjectMetadataRequest;
import com.amazonaws.services.s3.model.Grant;
import com.amazonaws.services.s3.model.ObjectListing;
import com.amazonaws.services.s3.model.ObjectMetadata;
import com.amazonaws.services.s3.model.Permission;
import com.amazonaws.services.s3.model.S3ObjectSummary;

public class UnEncryptedBucketListService {
	ArrayList<String> unEncrybucketsList = new ArrayList<>();
	ArrayList<String> globalAccessbucketsList = new ArrayList<>();

	public ArrayList<String> getUnEncryptedBucketsList(){
		String bucketName = null;
		AWSCredentials awsCredentials = 
			    new BasicAWSCredentials("AKIAIIEIMLM4CHWOX7TA", "tkIN+W5ZDJJbDjzy1vIyMXlwK+aM/tHPBHC40I6j");
		AmazonS3Client s3client = new AmazonS3Client(awsCredentials);
		for (Bucket bucket : s3client.listBuckets()) {
			bucketName = bucket.getName();
			System.out.println(" - " + bucket.getName());
			ObjectListing objects = s3client.listObjects(bucketName);
			List<S3ObjectSummary> s3ObjsSumry = objects.getObjectSummaries();
			int noOfObjs= s3ObjsSumry.size();
			System.out.println(noOfObjs);
			int noOfObjsUnEncrypt = 0;
			if(noOfObjs!=0){
				for(S3ObjectSummary s3Obj: s3ObjsSumry){
					if(s3Obj.getKey()!=null){
						GetObjectMetadataRequest gomr = new GetObjectMetadataRequest(bucketName, s3Obj.getKey());
						ObjectMetadata omd = s3client.getObjectMetadata(gomr);
						System.out.println("getContentEncoding-"+omd.getContentEncoding());
						System.out.println("getServerSideEncryption-"+omd.getServerSideEncryption());
						System.out.println("getContentMD5-"+omd.getContentMD5());
						System.out.println("getContentType-"+omd.getContentType());
						if(omd.getServerSideEncryption()==null){
							System.out.println("000000000000000");
							noOfObjsUnEncrypt++;
						}
					}
				}
				if(noOfObjs==noOfObjsUnEncrypt){
					unEncrybucketsList.add(bucketName);
				}
			}
		}
//				Map<String, Object> map = omd.getRawMetadata();
//				for (Map.Entry<String, Object> entry : map.entrySet()) {
//					System.out.println("Key : " + entry.getKey() + " Value : " + entry.getValue());
//					//amz-server-side-encryption
//				}
		return unEncrybucketsList;
	}

	public static void main(String agrs[]){
		//System.out.println(new UnEncryptedBucketListService().getUnEncryptedBucketsList());
		System.out.println(new UnEncryptedBucketListService().getGlobalAccessBucketsList());
		

		
//		AccessControlList acl = s3client.getBucketAcl("vztestbucket0616");
//		List<Grant> grantLst = acl.getGrantsAsList();
//		for(Grant gr : grantLst){
//			Permission prm = gr.getPermission();
//		
//		}
////		BucketPolicy bp = s3client.getBucketPolicy(new GetBucketPolicyRequest("vztestbucket0616"));
////		bp.
//		
//		GetObjectMetadataRequest gomr = new GetObjectMetadataRequest("bucketName", "key");
////		gomr.get
//		ObjectMetadata metadata = new ObjectMetadata();
////		metadata.
//		
//		ObjectListing objects = s3client.listObjects("vztestbucket0616");
//		List<S3ObjectSummary> s3ObjsSumry = objects.getObjectSummaries();
//		for(S3ObjectSummary s3Obj: s3ObjsSumry){
////			s3Obj.getBucketName().
//		}
//		System.out.println("=============="+objects.getEncodingType());
	}
	public ArrayList<String> getGlobalAccessBucketsList(){ 
		String bucketName = null;
		AWSCredentials awsCredentials = 
			    new BasicAWSCredentials("AKIAIIEIMLM4CHWOX7TA", "tkIN+W5ZDJJbDjzy1vIyMXlwK+aM/tHPBHC40I6j");
		AmazonS3Client s3client = new AmazonS3Client(awsCredentials);
		for (Bucket bucket : s3client.listBuckets()) {
			bucketName = bucket.getName();
			System.out.println(" - " + bucket.getName());
			AccessControlList acl = s3client.getBucketAcl(bucketName);
			List<Permission> permissions = new ArrayList<Permission>();
			for(Grant g: acl.getGrants()){
				System.out.println("--------------");
				//permissions.add(g.getPermission());
				Permission p = g.getPermission();
			}
		    if (permissions.contains(Permission.FullControl) || permissions.contains(Permission.Write)) {
		        System.out.println("validS3Sink = true");
		    }else{
		    	System.out.println("validS3Sink = false");
		    }
			System.out.println("#################################");
		}
		
		return globalAccessbucketsList;
	}
}